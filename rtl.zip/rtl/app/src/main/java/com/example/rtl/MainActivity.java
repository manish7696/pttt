package com.example.rtl;


import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    MediaRecorder mediaRecorder = new MediaRecorder();

    private Socket socket;
    private OutputStream outputStream;
    private static final int RECORD_AUDIO_PERMISSION_CODE = 1;
    private static final int INTERNET_PERMISSION_CODE = 1;

    private EditText ipAddressEditText; // EditText for IP address
    private Button audioStreamButton; // Button for audio streaming
    private ProgressBar progressBar; // Progress bar for connection

    private boolean isSending = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the MediaRecorder
//        MediaRecorder mediaRecorder = new MediaRecorder();

        // Initialize the EditText for IP address
        ipAddressEditText = findViewById(R.id.editTextIpAddress);

        // Initialize the TextView for messages
        // TextView for messages
        TextView messageTextView = findViewById(R.id.textViewMessage);

        // Initialize the Button for audio streaming
        audioStreamButton = findViewById(R.id.buttonAudioStream);
        audioStreamButton.setEnabled(false); // Initially disabled

        // Initialize the Progress bar for connection
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);

        // Check and request necessary permissions
        checkAndRequestPermissions();

        // Set up long-press listener for audio streaming
//        audioStreamButton.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View view) {
//                startAudioStreaming();
//                return true; // Consume the long-press event
//            }
//        });

        // Set up touch listener to stop audio streaming
        audioStreamButton.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    isSending = true;
                    sendTextMessage("Sound");
                }else if(event.getAction()==MotionEvent.ACTION_UP){
                    isSending = false;
                    stopAudioStreaming();
                }
                return false;
            }
        });
    }

    private void checkAndRequestPermissions() {
        String[] permissions = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.INTERNET
        };

        boolean allPermissionsGranted = true;

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                break;
            }
        }

        if (allPermissionsGranted) {
            showMessage("Permissions granted!");
        } else {
            ActivityCompat.requestPermissions(this, permissions, RECORD_AUDIO_PERMISSION_CODE);
            ActivityCompat.requestPermissions(this, permissions, INTERNET_PERMISSION_CODE);

        }
    }

    private void startAudioStreaming() {
        // Check if the socket is null or not connected
        if (socket == null || !socket.isConnected()) {
            showMessage("Socket not connected.");
            return;
        }

        // Send the text to the server
        try {
            outputStream = socket.getOutputStream();
            outputStream.write("2".getBytes());

        } catch (IOException e) {
            e.printStackTrace();
            showMessage("Failed to send text.");
            return;
        }

//        // Start audio recording
//        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
//        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
//        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
//        String audioPath = Environment.getExternalStorageDirectory().getPath() + "/temp.3gp";
//        mediaRecorder.setOutputFile(audioPath);
//        try {
//            mediaRecorder.prepare();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        mediaRecorder.start();
//        showMessage("Audio streaming started.");
    }

    private void stopAudioStreaming() {
//        // Stop audio recording and send data to the server
//        try{
//          mediaRecorder.stop();
//          mediaRecorder.release();
////        try {
//            outputStream.close();
//            socket.close();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
        showMessage(String.valueOf(socket.isConnected()));
        showMessage("Audio streaming stopped.");
    }

    // Connect to the server with the provided IP address
    public void connectToServer(View view) {
        final String ipAddress = ipAddressEditText.getText().toString();
        final int port = 6000; // Replace with your port number

        progressBar.setVisibility(View.VISIBLE); // Show progress bar

        // Create a socket and connect to the server on a background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    socket = new Socket();
                    socket.connect(new InetSocketAddress(ipAddress, port));
                    outputStream = socket.getOutputStream();
//                    outputStream.write("Text".getBytes());

                    // Connection successful, enable audio streaming
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                            showMessage("Connected to the server!");
                            audioStreamButton.setEnabled(true); // Enable audio streaming button
                        }
                    });
                } catch (IOException e) {
                    e.printStackTrace();
                    // Connection failed, show a toast message on the UI thread
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setVisibility(View.GONE);
                            showMessage("Failed to connect to the server.");
                        }
                    });
                }
            }
        }).start();
    }

    private void sendTextMessage(final String message) {
        if (socket == null || !socket.isConnected()) {
            showMessage("Socket not connected.");
            return;
        }

        int sampleRate = 44100;
        int audioSource = MediaRecorder.AudioSource.MIC;
        int channelConfig = AudioFormat.CHANNEL_IN_MONO;
        int audioFormat = AudioFormat.ENCODING_PCM_16BIT;
        int bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat);
        AudioRecord audioRecord = new AudioRecord(audioSource, sampleRate, channelConfig, audioFormat, bufferSize);

        audioRecord.startRecording();

        byte[] audioBuffer = new byte[bufferSize];
        // Send the text message to the server in a background thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] messageBytes = message.getBytes(StandardCharsets.UTF_8);
                    outputStream = socket.getOutputStream();
                    while (isSending) {
                        int bytesRead = audioRecord.read(audioBuffer, 0 , bufferSize);
                        if (bytesRead>0) {
                            outputStream.write(audioBuffer, 0, bytesRead);
                        }
                    }


                    // Optional: You can notify the user that the message was sent successfully
                    showMessage("Message sent: " + message);
                } catch (IOException e) {
                    e.printStackTrace();
                    showMessage(e.toString());
                }
                finally {
                    audioRecord.stop();
                    audioRecord.release();
                }
            }
        }).start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == RECORD_AUDIO_PERMISSION_CODE) {
            boolean allPermissionsGranted = true;
            for (int grantResult : grantResults) {
                if (grantResult != PackageManager.PERMISSION_GRANTED) {
                    allPermissionsGranted = false;
                    break;
                }
            }

            if (allPermissionsGranted) {
                showMessage("Permissions granted!");
            } else {
                showMessage("Permissions denied. The app requires these permissions to work.");
            }
        }
    }

    private void showMessage(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
}